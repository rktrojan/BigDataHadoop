module analytics {
	requires pmml.evaluator;
}