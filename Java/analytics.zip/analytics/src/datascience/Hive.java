package datascience;

import analytics.MapReduce;


//PUBLIC PRIVATE PROTECTED DEFAULT-PACKAGE access

public class Hive {

	public static void main(String[] args) {
		
		
		MapReduce obj= new MapReduce(11,222);
		int aa = obj.age;
		System.out.println(aa);
		
		double bb = obj.salary;
		System.out.println(bb);
		
	}
	
	
}
