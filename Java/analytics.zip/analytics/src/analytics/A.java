package analytics;

public interface A {

}
