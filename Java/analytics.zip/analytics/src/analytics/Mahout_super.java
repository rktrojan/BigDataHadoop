package analytics;

public class Mahout_super extends MapReduce{

	
	public void walk() {
		
		System.out.println("child is walking");
		//super.walk();
	}
	
		//method overriding
		public void walk2() {
		

		super.walk();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Mahout_super obj1 = new Mahout_super();
		int x = obj1.age;
		System.out.println(x);
		
		//method overriding
		obj1.walk();
		
		obj1.walk2();

	}

}
