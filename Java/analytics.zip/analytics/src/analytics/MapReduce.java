package analytics;


//CLASSES AND OBJECTS
public class MapReduce {

	//constructor overloading
	//method overloading

	
	public MapReduce(){
		age=909;
	}
	
	public MapReduce(int a){
		age=a;
		
	}
	
	public MapReduce(int a, int b){
		age=a;
		salary=b;
	}
	
	MapReduce(int a, double b){
		age=a;
		salary=b;
	}
	
	
	public int age;
	 public double salary;
	
	
	public int calc(int a, int b) {
		return a+b;
		
	}
	public void walk() {
		
		System.out.println("walking");
		
	}
	
	public void transmitter(String signal, String target) {
		System.out.println("trasmit " + signal + " to " + target);
	}
	
	public static void main(String[] args) {
		System.out.println("hello");
		
		
		MapReduce obj1 = new MapReduce(11,22.88);
		//MapReduce obj2 = new MapReduce();
		//walk();
		
		obj1.walk();
		obj1.transmitter("how r u", "10.1.1.2");
		
		System.out.println(obj1.age);
		System.out.println(obj1.salary);
		
		int summation=obj1.calc(22,44);
		System.out.println(summation);
	
	
	}

}




