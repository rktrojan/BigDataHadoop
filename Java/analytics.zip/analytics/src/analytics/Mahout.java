package analytics;


//INHERITANCE

public class Mahout extends MapReduce{

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Mahout obj1 = new Mahout();
		int x = obj1.age;
		System.out.println(x);
		
		//accessing parent function from child
		obj1.walk();
		

	}

}
