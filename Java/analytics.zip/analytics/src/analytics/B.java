package analytics;

public interface B {

}
