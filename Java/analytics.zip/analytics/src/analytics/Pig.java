package analytics;

import analytics.MapReduce;


//PUBLIC PRIVATE PROTECTED DEFAULT-PACKAGE access
public class Pig {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pig pp = new Pig();
		//pp.age
		MapReduce obj= new MapReduce(11,112);
		int aa = obj.age;
		System.out.println(aa);
	}

}
