package analytics;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.LoadingModelEvaluatorBuilder;
import org.xml.sax.SAXException;

public class pmmlrunner2 {
	
	public static void main(String[] args) {
		
		// Building a model evaluator from a PMML file
		Evaluator evaluator;
		try {
			evaluator = new LoadingModelEvaluatorBuilder().load(new File("model.pmml")).build();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Perforing the self-check
		evaluator.verify();
		
	}
	
	
	


}
