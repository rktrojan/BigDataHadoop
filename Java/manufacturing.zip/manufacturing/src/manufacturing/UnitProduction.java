package manufacturing;

public class UnitProduction {

	int abc;
	String name;
	public int height=88;
	
	
	
public static String produce() {
	return "hello";
}	
	
	
public static void main(String[] args) {
		
		int a,b,A;
		A=44;
		a=2;
		b=4;
int c=a+b;
		String x= produce();
				
	System.out.println("Hello Program " + c);
	System.out.println(x);
	
	System.out.println(A );
	
	System.out.println(a );
	
	//create object
	
	//UnitProduction rahul=new UnitProduction();
	
	
	}




}
