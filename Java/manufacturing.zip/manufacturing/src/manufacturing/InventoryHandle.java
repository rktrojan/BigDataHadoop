package manufacturing;

public class InventoryHandle extends UnitProduction
{
	
	int s=2;
	
	public static void main(String [] args)
	{
		InventoryHandle IH = new InventoryHandle();
		InventoryHandle Ajay = new InventoryHandle();

		System.out.println("salary for IH " +IH.s
				);
		
		//Inheritance example
		System.out.println("height for IH " +IH.height
				);
		
		
		
		System.out.println("salary for Ajay " + (Ajay.s +10)
				);
		
		
	}

}
