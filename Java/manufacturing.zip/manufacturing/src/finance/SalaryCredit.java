package finance;

public class SalaryCredit {

}
